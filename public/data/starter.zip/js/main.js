import {
    tad,
    shape,
} from "../lib/TeachAndDraw.js"; 

tad.use(update); //important

function update() {
    shape.circle(400, 300, 200)
}